var struct_dapper_labs_1_1_flow_1_1_sdk_1_1_wallet_connect_1_1_wallet_select_dialog_1_1_wallet_provider_data =
[
    [ "BaseUri", "struct_dapper_labs_1_1_flow_1_1_sdk_1_1_wallet_connect_1_1_wallet_select_dialog_1_1_wallet_provider_data.html#a33a18d378f1ef8650d56706ce9c70dc6", null ],
    [ "ConnectUri", "struct_dapper_labs_1_1_flow_1_1_sdk_1_1_wallet_connect_1_1_wallet_select_dialog_1_1_wallet_provider_data.html#ae59bf4cc46dd948a4d427d01e7b78f7e", null ],
    [ "Icon", "struct_dapper_labs_1_1_flow_1_1_sdk_1_1_wallet_connect_1_1_wallet_select_dialog_1_1_wallet_provider_data.html#a8d321514b7d2f5466ac4caebb7c3914c", null ],
    [ "IsInstalled", "struct_dapper_labs_1_1_flow_1_1_sdk_1_1_wallet_connect_1_1_wallet_select_dialog_1_1_wallet_provider_data.html#a4af35f902e4e2ae07cc8cf2a8f820773", null ],
    [ "Name", "struct_dapper_labs_1_1_flow_1_1_sdk_1_1_wallet_connect_1_1_wallet_select_dialog_1_1_wallet_provider_data.html#af207fc3dbc6281d45afacd3200a5bbe4", null ]
];