var class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_transaction_proposal_key =
[
    [ "Address", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_transaction_proposal_key.html#a04ee4c0ae3f45f89df43b159ac58f850", null ],
    [ "KeyId", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_transaction_proposal_key.html#a99d5266c6495d0a7e7c598c66b7182fb", null ],
    [ "SequenceNumber", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_transaction_proposal_key.html#a6ceeb8ea0c8fff889815d4dfbd204c75", null ]
];