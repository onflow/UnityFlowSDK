var class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_niftory_config =
[
    [ "AuthUrl", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_niftory_config.html#a8c9b2cbceb8d06ee8f61c88849b74dd7", null ],
    [ "ClientId", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_niftory_config.html#af80d8de1b0b612f2bbbffd3c10601d07", null ],
    [ "GraphQLUrl", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_niftory_config.html#a98eb2664aab38461e7d26a9bba0fecd4", null ],
    [ "QrCodeDialogPrefab", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_niftory_config.html#a3834ed87dcb6734f36d51fbfffc6f9a7", null ]
];