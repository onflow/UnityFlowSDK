var class_dapper_labs_1_1_flow_1_1_sdk_1_1_cadence_1_1_cadence_link_value =
[
    [ "BorrowType", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_cadence_1_1_cadence_link_value.html#a68d931242705647fbb8d43e2fb0b6872", null ],
    [ "TargetPath", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_cadence_1_1_cadence_link_value.html#aee9cbc2d807df45ae1c8bb55c28657ae", null ]
];