var class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_event_group =
[
    [ "BlockHeight", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_event_group.html#a7f0ee9b9f32babce5e9180cc4c039500", null ],
    [ "BlockId", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_event_group.html#aeb08791cae895732d7be185e5197ac53", null ],
    [ "BlockTimestamp", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_event_group.html#ab9ea96cc4460b213ac57668ee1246e4d", null ],
    [ "Error", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_event_group.html#a04f7a9e84a8ef09b1f9bee713fa2e2e8", null ],
    [ "Events", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_event_group.html#a9fb55111fc4248e08cc500d38559962e", null ]
];