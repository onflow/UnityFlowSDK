var class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_q_r_code_dialog =
[
    [ "Init", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_q_r_code_dialog.html#a5669ccffba0a42d22487cf381db7a2be", null ],
    [ "OnCloseButtonClicked", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_q_r_code_dialog.html#a38a3dca1d90374c80080d68b4fe27c68", null ],
    [ "OnCopyUriMouseHoverEnter", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_q_r_code_dialog.html#ad2c94cf7a6f93892a0cb67497762af8a", null ],
    [ "OnCopyUriMouseHoverExit", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_q_r_code_dialog.html#a512467f63b9642bed6e44e7086a8d5fc", null ],
    [ "OnUriClicked", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_q_r_code_dialog.html#a3ec50f235a4ffae2267de5a51c2e57bc", null ],
    [ "CodeText", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_q_r_code_dialog.html#a2c1b416759315385dd516a51cd404a9d", null ],
    [ "Dialog", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_q_r_code_dialog.html#a46bbc4101734714cd275898264ad0fe4", null ],
    [ "LoadingIndicator", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_q_r_code_dialog.html#ab31aafd1bfcbc202aef195ab699ac934", null ],
    [ "QrCodeObject", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_q_r_code_dialog.html#a8ad23e386bc53b937c4a04bcbc15d29b", null ],
    [ "UriButtonText", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_q_r_code_dialog.html#aa8ff82d4c437391070b492186ed10ffe", null ]
];