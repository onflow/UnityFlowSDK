var class_dapper_labs_1_1_flow_1_1_sdk_1_1_wallet_connect_1_1_wallet_select_dialog_provider =
[
    [ "InstalledIndicator", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_wallet_connect_1_1_wallet_select_dialog_provider.html#a6ab2d9bfa1441330ab346ecf0e9bb6b2", null ],
    [ "ProviderIcon", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_wallet_connect_1_1_wallet_select_dialog_provider.html#af02fe6b555b940b1c9964009ff1fe06d", null ],
    [ "ProviderName", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_wallet_connect_1_1_wallet_select_dialog_provider.html#a02b30417e8709c0a082ead24bcf3ab66", null ],
    [ "SelectButton", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_wallet_connect_1_1_wallet_select_dialog_provider.html#aaaa45fd858e367ea41a67e857c908796", null ]
];