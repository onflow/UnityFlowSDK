/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Unity FlowSDK", "index.html", [
    [ "Version 2.0.0", "md__c_h_a_n_g_e_l_o_g.html", [
      [ "Version 1.0.3", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md2", null ],
      [ "Version 1.0.2", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md3", null ],
      [ "Version 1.0.1", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md4", null ],
      [ "Version 1.0.0", "md__c_h_a_n_g_e_l_o_g.html#autotoc_md5", null ]
    ] ],
    [ "LICENSE", "md__l_i_c_e_n_s_e.html", null ],
    [ "Flow SDK for Unity", "md__r_e_a_d_m_e.html", [
      [ "Overview", "md__r_e_a_d_m_e.html#autotoc_md7", [
        [ "Which should I use?", "md__r_e_a_d_m_e.html#autotoc_md8", null ],
        [ "Asynchronous programming", "md__r_e_a_d_m_e.html#autotoc_md9", null ],
        [ "FlowControl", "md__r_e_a_d_m_e.html#autotoc_md10", null ]
      ] ],
      [ "Requirements", "md__r_e_a_d_m_e.html#autotoc_md11", null ],
      [ "Documentation", "md__r_e_a_d_m_e.html#autotoc_md12", null ]
    ] ],
    [ "Third Party Notices", "md__third__party__notices.html", null ],
    [ "Namespaces", "namespaces.html", [
      [ "Namespace List", "namespaces.html", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Enumerations", "namespacemembers_enum.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", null ],
        [ "Variables", "functions_vars.html", null ],
        [ "Enumerations", "functions_enum.html", null ],
        [ "Properties", "functions_prop.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"class_dapper_labs_1_1_flow_1_1_sdk_1_1_cadence_1_1_types_1_1_cadence_composite_type.html#a4b878cb8a28413760f94ee6b49716811",
"class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_chunk.html#aa87ab02c3004d280ac949f2299bc3ded",
"class_dapper_labs_1_1_flow_1_1_sdk_1_1_unity_1_1_emulator_gateway.html#ac08025446ae1adf7b6f2566bf2006ac9",
"class_dapper_labs_1_1_flow_1_1_sdk_1_1_wallet_connect_1_1_wallet_select_dialog_provider.html#af02fe6b555b940b1c9964009ff1fe06d"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';