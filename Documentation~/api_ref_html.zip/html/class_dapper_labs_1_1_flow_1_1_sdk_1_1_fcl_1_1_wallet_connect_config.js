var class_dapper_labs_1_1_flow_1_1_sdk_1_1_fcl_1_1_wallet_connect_config =
[
    [ "ProjectDescription", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_fcl_1_1_wallet_connect_config.html#a0264e2f9c0a40aff3dabedae78792105", null ],
    [ "ProjectIconUrl", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_fcl_1_1_wallet_connect_config.html#a23db7180f44bcd085a89adf09cc50286", null ],
    [ "ProjectId", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_fcl_1_1_wallet_connect_config.html#ab040c9a994697f93ec83dee1dcca0469", null ],
    [ "ProjectName", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_fcl_1_1_wallet_connect_config.html#a5d08bbf14ba231600b318b7fc4d88144", null ],
    [ "ProjectUrl", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_fcl_1_1_wallet_connect_config.html#a954c714afbb7e3a16a5731bd317a4dee", null ],
    [ "QrCodeDialogPrefab", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_fcl_1_1_wallet_connect_config.html#a31834a317d050e48b81efb58cacf4597", null ],
    [ "WalletSelectDialogPrefab", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_fcl_1_1_wallet_connect_config.html#a57c9ec430d8ab1dbfca7166bbe1eeb42", null ]
];