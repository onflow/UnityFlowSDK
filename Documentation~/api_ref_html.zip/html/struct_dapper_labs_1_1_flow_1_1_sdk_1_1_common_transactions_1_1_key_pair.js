var struct_dapper_labs_1_1_flow_1_1_sdk_1_1_common_transactions_1_1_key_pair =
[
    [ "privateKey", "struct_dapper_labs_1_1_flow_1_1_sdk_1_1_common_transactions_1_1_key_pair.html#aec96dfd5eadfcd8070a763017641cf57", null ],
    [ "publicKey", "struct_dapper_labs_1_1_flow_1_1_sdk_1_1_common_transactions_1_1_key_pair.html#a89b6981a65d9e10e7ce175af8b1b7238", null ]
];