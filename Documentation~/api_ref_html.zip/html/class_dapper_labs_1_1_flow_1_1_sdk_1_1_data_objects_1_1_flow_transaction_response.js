var class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_transaction_response =
[
    [ "Error", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_transaction_response.html#a168a209527715766db3f39e5db5c3747", null ],
    [ "Id", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_transaction_response.html#ae5cf7abe6e8b3069dd7264e6ff11a076", null ]
];