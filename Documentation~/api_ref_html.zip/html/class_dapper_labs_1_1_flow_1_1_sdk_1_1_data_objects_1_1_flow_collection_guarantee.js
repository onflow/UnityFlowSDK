var class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_collection_guarantee =
[
    [ "CollectionId", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_collection_guarantee.html#aef0fe2fa2c3681e6448a7c4850fe60be", null ],
    [ "Signatures", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_collection_guarantee.html#a07eca1d495675205b70d8fc633e03ac1", null ]
];