var class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_block_seal =
[
    [ "BlockId", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_block_seal.html#aabc340d333027aac286f681c76cbfc8e", null ],
    [ "ExecutionReceiptId", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_block_seal.html#af03f9481534571f861c05461b8b0f9e1", null ],
    [ "ExecutionReceiptSignatures", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_block_seal.html#a473755259dc3ed63e90224dd179fecf8", null ],
    [ "ResultApprovalSignatures", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_block_seal.html#a7646cab5d25616f75b5c46d95f8a0824", null ]
];