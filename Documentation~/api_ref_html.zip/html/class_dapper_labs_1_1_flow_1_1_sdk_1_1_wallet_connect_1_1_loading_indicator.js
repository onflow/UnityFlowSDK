var class_dapper_labs_1_1_flow_1_1_sdk_1_1_wallet_connect_1_1_loading_indicator =
[
    [ "RotationInterval", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_wallet_connect_1_1_loading_indicator.html#ae43962e6115348aeb944b4e91803b57e", null ],
    [ "RotationSpeed", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_wallet_connect_1_1_loading_indicator.html#aed0addc741ef500c4e6a0be39f0ad55c", null ]
];