var class_dapper_labs_1_1_flow_1_1_sdk_1_1_wallet_connect_1_1_wallet_connect_config =
[
    [ "ProjectDescription", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_wallet_connect_1_1_wallet_connect_config.html#a1dc2d54b9373e2640c8096c42c89e5cc", null ],
    [ "ProjectIconUrl", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_wallet_connect_1_1_wallet_connect_config.html#acd7250e36fb2ce35c1a52f107e5bd4d2", null ],
    [ "ProjectId", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_wallet_connect_1_1_wallet_connect_config.html#acfac63023917f8bc343724f18ddf3c84", null ],
    [ "ProjectName", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_wallet_connect_1_1_wallet_connect_config.html#a851ef0abe7eae48a38b898d7d9559d52", null ],
    [ "ProjectUrl", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_wallet_connect_1_1_wallet_connect_config.html#a86276207c6b620a8b6f1ac7e24d9cdc0", null ],
    [ "QrCodeDialogPrefab", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_wallet_connect_1_1_wallet_connect_config.html#a28b1f80c6f672a298e1918350d3ab0e5", null ],
    [ "WalletSelectDialogPrefab", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_wallet_connect_1_1_wallet_connect_config.html#a92645dcdfad470b86919ce6701791a19", null ]
];