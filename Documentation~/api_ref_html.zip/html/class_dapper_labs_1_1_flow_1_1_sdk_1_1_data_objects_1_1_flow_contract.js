var class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_contract =
[
    [ "Code", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_contract.html#a9522f7cee3421112fc794743da09aea6", null ],
    [ "Name", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_contract.html#a88f234b1510c3af63c9728751ac8295d", null ]
];