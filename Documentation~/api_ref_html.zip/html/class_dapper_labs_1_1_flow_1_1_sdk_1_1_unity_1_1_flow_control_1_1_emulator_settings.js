var class_dapper_labs_1_1_flow_1_1_sdk_1_1_unity_1_1_flow_control_1_1_emulator_settings =
[
    [ "emulatorDataDirectory", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_unity_1_1_flow_control_1_1_emulator_settings.html#ab85f3cd1777fe49e4b53c66dadb64386", null ],
    [ "emulatorEndpoint", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_unity_1_1_flow_control_1_1_emulator_settings.html#ad2124f47dfaa3e30e0827e68409760c0", null ],
    [ "flowExecutablePathOverride", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_unity_1_1_flow_control_1_1_emulator_settings.html#a9b04a310a7fb2bbb308e6adca5578bc4", null ],
    [ "killOtherFlow", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_unity_1_1_flow_control_1_1_emulator_settings.html#ac568174e42f17fbd3c5d777e150cc829", null ],
    [ "persistData", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_unity_1_1_flow_control_1_1_emulator_settings.html#af89435ab31271ab24d059aab1cda459e", null ],
    [ "runEmulatorInPlayMode", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_unity_1_1_flow_control_1_1_emulator_settings.html#a3562344d62603fb553616c144c076159", null ],
    [ "verbose", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_unity_1_1_flow_control_1_1_emulator_settings.html#a12ea011ec574111e6e2352cc2fb418e6", null ]
];