var class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_event =
[
    [ "EventIndex", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_event.html#a694046a825107c486982cf3fab24e3f9", null ],
    [ "Payload", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_event.html#ad5057d98505974b91f4c8bb8074cb92c", null ],
    [ "TransactionId", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_event.html#a4cfe8079fa4c98275c817733f013360c", null ],
    [ "TransactionIndex", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_event.html#a3a91e79773fab0ccfb283933e016cf3e", null ],
    [ "Type", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_event.html#a9fb8208151245d176c442720bab0c45b", null ]
];