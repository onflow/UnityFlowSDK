var class_dapper_labs_1_1_flow_1_1_sdk_1_1_dev_wallet_1_1_transaction_dialog =
[
    [ "Init", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_dev_wallet_1_1_transaction_dialog.html#af10a7ac23dfd3ae3d2ce017597c375d8", null ]
];