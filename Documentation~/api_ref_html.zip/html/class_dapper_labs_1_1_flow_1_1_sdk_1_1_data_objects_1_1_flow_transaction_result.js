var class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_transaction_result =
[
    [ "Error", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_transaction_result.html#aad471336ce5e1463872bbdc1009b1367", null ],
    [ "ErrorMessage", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_transaction_result.html#a913abf6486b35f6141af959fbe92b5e0", null ],
    [ "Events", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_transaction_result.html#a4ae078715cb92893b187aa208ed75baf", null ],
    [ "Status", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_transaction_result.html#a051eef6f9769420a58365a335578167c", null ],
    [ "StatusCode", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_transaction_result.html#af0c2f5898e8b85e39e8ca01a85150e3f", null ]
];