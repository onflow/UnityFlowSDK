var class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_niftory_provider =
[
    [ "Authenticate", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_niftory_provider.html#a281ce707c420bd9e4555dd4b51347d9e", null ],
    [ "GetAuthenticatedAccount", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_niftory_provider.html#aca1e824c878cb7bf258726a82ace7118", null ],
    [ "Init", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_niftory_provider.html#af0a00d39234bd3c6b60621798f7f3a76", null ],
    [ "IsAuthenticated", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_niftory_provider.html#a63b331f19f363729f1f8acb0ff947735", null ],
    [ "LinkToAccount", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_niftory_provider.html#af00fa147aac2fac128665174f342ead6", null ],
    [ "Mutate", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_niftory_provider.html#aa30523c5f46f28d85d3dde9f3f60733f", null ],
    [ "SignTransactionEnvelope", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_niftory_provider.html#af9e1748a0e18ee77394a8917203fd4ed", null ],
    [ "SignTransactionPayload", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_niftory_provider.html#a2108b2f21fd78aa200d4a76c4a2c4d74", null ],
    [ "Unauthenticate", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_niftory_provider.html#a43b8a2a6fc0e98c50276aec99c071693", null ]
];