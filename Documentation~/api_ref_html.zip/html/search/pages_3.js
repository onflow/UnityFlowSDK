var searchData=
[
  ['version_202_2e0_2e0_0',['Version 2.0.0',['../md__c_h_a_n_g_e_l_o_g.html',1,'']]]
];
