var searchData=
[
  ['license_0',['LICENSE',['../md__l_i_c_e_n_s_e.html',1,'']]]
];
