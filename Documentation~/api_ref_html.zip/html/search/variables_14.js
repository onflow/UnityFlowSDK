var searchData=
[
  ['uricopybuttontext_0',['UriCopyButtonText',['../class_dapper_labs_1_1_flow_1_1_sdk_1_1_wallet_connect_1_1_q_r_code_dialog.html#aad4ae954503dbd0ead7c18227c625b9f',1,'DapperLabs::Flow::Sdk::WalletConnect::QRCodeDialog']]]
];
