var indexSectionsWithContent =
{
  0: "abcdefghijklmnopqrstuvw",
  1: "abcdefgklmnqstw",
  2: "d",
  3: "acdefgiorstu",
  4: "abcdefghijklmnopqrstuvw",
  5: "cfn",
  6: "abcdefgiklmnprstv",
  7: "fltv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "properties",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Properties",
  7: "Pages"
};

