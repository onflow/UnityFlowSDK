var searchData=
[
  ['borrowtype_0',['BorrowType',['../class_dapper_labs_1_1_flow_1_1_sdk_1_1_cadence_1_1_cadence_capability_value.html#a223244609dbaa5769c1a65c8dcf944da',1,'DapperLabs.Flow.Sdk.Cadence.CadenceCapabilityValue.BorrowType()'],['../class_dapper_labs_1_1_flow_1_1_sdk_1_1_cadence_1_1_cadence_link_value.html#a68d931242705647fbb8d43e2fb0b6872',1,'DapperLabs.Flow.Sdk.Cadence.CadenceLinkValue.BorrowType()']]]
];
