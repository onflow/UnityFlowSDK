var class_dapper_labs_1_1_flow_1_1_sdk_1_1_unity_1_1_flow_control_1_1_text_replacement =
[
    [ "active", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_unity_1_1_flow_control_1_1_text_replacement.html#af68ad190e5a50d05cd3d0e34c7c608db", null ],
    [ "description", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_unity_1_1_flow_control_1_1_text_replacement.html#a56c70000ddb80f174ee7e2273a2bc995", null ],
    [ "originalText", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_unity_1_1_flow_control_1_1_text_replacement.html#a42e58a43ecc0edec92b08734368d4a16", null ],
    [ "replacementText", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_unity_1_1_flow_control_1_1_text_replacement.html#a5592efb7409dbb3b316b24c830dd947e", null ],
    [ "ApplyToAccounts", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_unity_1_1_flow_control_1_1_text_replacement.html#a3af13cbaf7c594faf839c22333822226", null ],
    [ "ApplyToGateways", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_unity_1_1_flow_control_1_1_text_replacement.html#a77b234c80d95e05fed4a9c9993880f8c", null ]
];