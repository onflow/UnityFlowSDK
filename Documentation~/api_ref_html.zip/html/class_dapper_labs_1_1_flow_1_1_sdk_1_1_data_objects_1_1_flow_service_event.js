var class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_service_event =
[
    [ "Payload", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_service_event.html#a858dc1d68229b0a653a664a6958965c6", null ],
    [ "Type", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_service_event.html#ae19c3203433e141cdbbd37bcb129fa4c", null ]
];