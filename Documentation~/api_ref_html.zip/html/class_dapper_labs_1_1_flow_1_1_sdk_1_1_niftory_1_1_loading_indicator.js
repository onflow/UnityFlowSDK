var class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_loading_indicator =
[
    [ "RotationInterval", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_loading_indicator.html#a51655fae94915c9f8de8b3f3937d4e97", null ],
    [ "RotationSpeed", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_niftory_1_1_loading_indicator.html#a1a61b5f09763d36fdbe36dca2e875e36", null ]
];