var class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_collection =
[
    [ "Error", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_collection.html#a7e8443f8e8f2974a3e127cf2bef3cef8", null ],
    [ "Id", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_collection.html#a43072f779a684e2b9960ca9808d3c87b", null ],
    [ "TransactionIds", "class_dapper_labs_1_1_flow_1_1_sdk_1_1_data_objects_1_1_flow_collection.html#ac83a3dc9a0c6b2f8d953ceb8215b38f0", null ]
];